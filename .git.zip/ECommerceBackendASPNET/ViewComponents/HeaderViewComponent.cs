﻿using Microsoft.AspNetCore.Mvc;

namespace ECommerceBackendASPNET.ViewComponents
{
    public class HeaderViewComponent : ViewComponent
    {
    }
}
