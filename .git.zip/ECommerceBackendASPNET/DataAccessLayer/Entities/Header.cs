﻿namespace ECommerceBackendASPNET.DataAccessLayer.Entities
{
    public class Header : Entity
    {
    }
}
