﻿namespace ECommerceBackendASPNET.DataAccessLayer.Entities
{
    public class Entity
    {
        public int Id { get; set; }
    }
}
