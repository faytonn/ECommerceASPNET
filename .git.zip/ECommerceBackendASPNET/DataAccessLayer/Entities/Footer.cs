﻿namespace ECommerceBackendASPNET.DataAccessLayer.Entities
{
    public class Footer : Entity
    {
    }
}
